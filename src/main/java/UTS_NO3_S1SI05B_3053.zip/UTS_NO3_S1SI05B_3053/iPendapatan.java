
package UTS_NO3_S1SI05B_3053;


public interface iPendapatan {
    public double totalPendapatan();
}


