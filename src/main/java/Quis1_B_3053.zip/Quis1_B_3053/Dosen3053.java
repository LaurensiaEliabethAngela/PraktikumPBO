
package Quis1_B_3053;


public class Dosen3053 {
    
    String Nik;
    String Nama;
    int Umur;
    String Alamat;
    String Nidn;
    String gol;
    int GajiPokok;
    
}
