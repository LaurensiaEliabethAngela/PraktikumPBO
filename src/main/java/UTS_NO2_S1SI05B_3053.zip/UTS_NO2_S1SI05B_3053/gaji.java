
package UTS_NO2_S1SI05B_3053;


public class gaji {
    public static void main (String [] args)
    {
        Employer ref;
        salariedEmployer pekerja=new salariedEmployer();
        commisionEmploye pegawai=new commisionEmploye();
        projectPlanner atasan=new projectPlanner();
     
        System.out.println ("DAFTAR GAJI KARYAWAN");
        System.out.println ("\n");
     
        ref=pekerja;     
        ref.setNama ("Indra");
        ref.getNama();
        ref.jabatan_3053();
        ref.perhitungangaji();
        System.out.println ("\n");
     
        ref=pegawai;
        ref.setNama ("pamungkas");
        ref.getNama();
        ref.jabatan_3053();
        ref.perhitungangaji();
        System.out.println ("\n");
        ref=atasan;
        ref.setNama ("Angela");
        ref.getNama();
        ref.jabatan_3053();
        ref.perhitungangaji();
    }
}

