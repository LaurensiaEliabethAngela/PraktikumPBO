
package Quis1_B_3053;


public class Mahasiswa3053 {
    //Data Mahasiswa
    private String Nik;
    private String Nama;
    private int Umur;
    private String Alamat;
    private String Nim;
    private float Ipk;
    
    //Data Beasiswa
    
}
