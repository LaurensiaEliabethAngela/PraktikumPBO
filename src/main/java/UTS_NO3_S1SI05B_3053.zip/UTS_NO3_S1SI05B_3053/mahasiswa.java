
package UTS_NO3_S1SI05B_3053;


public class mahasiswa {
    
    protected String nim;
    protected String nama;
    protected String jurusan;
    protected int ipk;
    
    public void tampilDataMhs(){
        
    }
    
}


